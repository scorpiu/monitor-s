package com.ideal.order.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.ideal.entity.OfferAttrEntity;
import com.ideal.entity.OfferEntity;
import com.ideal.entity.OfferInstRelEntity;
import com.ideal.entity.OfferProdRelEntity;
import com.ideal.entity.OfferRelEntity;
import com.ideal.entity.ProdAttrEntity;
import com.ideal.entity.ProdInstRelEntity;
import com.ideal.entity.ProdRelEntity;
import com.ideal.entity.ProductEntity;
import com.ideal.order.dto.OrderAddedDto;
import com.ideal.order.dto.OrderCartDto;
import com.ideal.order.dto.OrderProdDto;
import com.ideal.order.dto.OrderSubmitAddedDto;
import com.ideal.order.dto.OrderSubmitDto;
import com.ideal.order.dto.OrderSubmitOfferDto;
import com.ideal.order.dto.OrderSubmitProDto;
import com.ideal.order.mapper.OrderMapper;
import com.ideal.order.service.OrderService;

/**
* @author JJB
* @version 创建时间：2019年1月23日 下午1:30:45
*
*/
@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	private OrderMapper orderMapper;

	//查看购物车
	@Override
	public List<OrderCartDto> getAllCart(String uSER_NAME) {
		// TODO Auto-generated method stub
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("USER_NAME", uSER_NAME);
		List<OrderCartDto> cart = new ArrayList<OrderCartDto>();
		//该用户购物车所有商品
		List<OrderCartDto> allCart = orderMapper.getAllCart(map);
		List<OrderCartDto> groupOffer = new ArrayList<OrderCartDto>();
		List<OrderCartDto> coup = new ArrayList<OrderCartDto>();

		for (int i = 0; i < allCart.size(); i++) {
			OrderCartDto orderCartDto = allCart.get(i);
			map.put("OFFER_ID", orderCartDto.getOFFER_ID());
			//组合商品的具体商品
			List<OrderCartDto> flag = orderMapper.getGroupOffer(map);
			List<OrderProdDto> prodDtos = new ArrayList<OrderProdDto>();
			List<OrderAddedDto> addedDtos = new ArrayList<OrderAddedDto>();
			if(flag != null && flag.size()>0){
				for (OrderCartDto zi : flag) {
					map.put("OFFER_ID", zi.getOFFER_ID());
					map.put("zu", "zu");
					//产品获取
					List<OrderProdDto> prodDto = orderMapper.getAllProd(map);
					if(prodDto!=null){
						prodDtos.addAll(prodDto);
					}
					//加装包获取
					List<OrderAddedDto> addedDto = orderMapper.getAllAdded(map);
					if(addedDto!=null && addedDto.size()>0 ){
						addedDtos.addAll(addedDto);
					}
				}
				allCart.get(i).setOrderProdDto(prodDtos);
				allCart.get(i).setOrderAddedDto(addedDtos);
			}else{
				//产品获取
				map.remove("zu", "zu");
				map.put("OFFER_ID", orderCartDto.getOFFER_ID());
				List<OrderProdDto> prodDto = orderMapper.getAllProd(map);
				if(prodDto!=null){
					prodDtos.addAll(prodDto);
				}
				allCart.get(i).setOrderProdDto(prodDtos);
			}

			if(addedDtos.size()>0){
				allCart.get(i).setAdded(true);
			}else{
				allCart.get(i).setAdded(false);
			}

		}
//		if(allCart!=null){
//			allCart.removeAll(coup);
//			allCart.addAll(groupOffer);
//			cart.addAll(allCart);
//		}
		//加装包
//		for (OrderCartDto c : cart) {
//			map.put("OFFER_ID", c.getOFFER_ID());
//			//加装包获取
//			List<OrderAddedDto> addedDto = orderMapper.getAllAdded(map);
//			if(addedDto!=null && addedDto.size()>0 ){
//				c.setAdded(true);
//				c.setOrderAddedDto(addedDto);
//			}else{
//				c.setAdded(false);
//			}
//			//产品获取
//			List<OrderProdDto> prodDto = orderMapper.getAllProd(map);
//			if(prodDto!=null){
//				c.setOrderProdDto(prodDto);
//			}
//		}
		cart.addAll(allCart);
		return cart;
	}

	//提交订单
	/*@Override
	public List<OrderCartDto> addCartOrder(String order) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		OrderSubmitDto orderSubmitDto = (OrderSubmitDto)JSONObject.parse(order);
		Map<String,Object> map = new HashMap<String,Object>();


			String user_NAME = orderSubmitDto.getUSER_NAME();
			String eff_DATE = orderSubmitDto.getEFF_DATE();
			String exp_DATE = orderSubmitDto.getEXP_DATE();
			String pricing = orderSubmitDto.getPRICING();
			SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmss");
			SimpleDateFormat sdf2 = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
			String SERIAL = sdf.format(new Date());
			map.put("SERIAL", SERIAL);
			map.put("USER_NAME", user_NAME);
			map.put("EFF_DATE", eff_DATE);
			map.put("EXP_DATE", exp_DATE);
			map.put("PRICING", pricing);
			map.put("ORDER_DATE", sdf2.format(new Date()));
			map.put("STATUS", "已结算");
			map.put("ORDER_CONTENT", JSONObject.toJSONString(orderSubmitDto));
			orderMapper.addSubmintOrder(map);

			List<OrderSubmitOfferDto> orderSubmitOfferDtoList = orderSubmitDto.getOrderSubmitOfferDtoList();
			for (OrderSubmitOfferDto orderSubmitOfferDto : orderSubmitOfferDtoList) {

				List<OfferEntity> queryOffer = orderMapper.queryOffer(map);
				OfferEntity off= new OfferEntity();
				off.setOFFER_ID(orderSubmitOfferDto.getOFFER_ID());
				queryOffer.add(off);

				ArrayList<String> insts = new ArrayList<String>();
				//offer实例
				for (OfferEntity offerEntity : queryOffer) {
					map.put("OFFER_ID", offerEntity.getOFFER_ID());
					OfferInstEntity oi = new OfferInstEntity();
					oi.setCUST_ID(user_NAME);
					oi.setOFFER_ID(offerEntity.getOFFER_ID());
					oi.setCUST_ORDER_NBR(SERIAL);
					oi.setEFF_DATE(eff_DATE);
					oi.setEXP_DATE(exp_DATE);
					orderMapper.addOfferOrder(oi);
					String offer_INST_ID = oi.getOFFER_INST_ID();
					map.put("OFFER_INST_ID", offer_INST_ID);
					if(orderSubmitOfferDto.getOFFER_ID().equals(offerEntity.getOFFER_ID())){map.put("fu",offer_INST_ID);}else{
						insts.add(offer_INST_ID);
					}
					//offer_attr
					List<OfferAttrEntity> queryOfferAttr = orderMapper.queryOfferAttr(map);
					Map<String,Object> attrMap = new HashMap<String,Object>();
					for (OfferAttrEntity offerAttrEntity : queryOfferAttr) {
						map.put("ATTR_ID", offerAttrEntity.getATTR_ID());
						map.put("ATTR_VALUE", offerAttrEntity.getDEFAULT_VALUE());
						orderMapper.addOfferAttr(map);
					}
				}
				//offer_rel实例
				for (String inst : insts) {
					map.put("OFFER_INST_ID", inst);
					map.put("PAR_OFFER_INST_ID", map.get("fu"));
					orderMapper.addOfferRel(map);
				}

				List<OrderSubmitProDto> proDtoList = orderSubmitOfferDto.getProDtoList();
				List<OrderSubmitAddedDto> addedDtoList = orderSubmitOfferDto.getAddedDtoList();
			}


		return null;
	}*/

	//提交订单
	@Override
	public List<OrderCartDto> addCartOrder(String order) {
		// TODO Auto-generated method stub
//		OrderSubmitDto orderSubmitDto = (OrderSubmitDto)JSONObject.parse(order);
		OrderSubmitDto orderSubmitDto = JSON.parseObject(order, OrderSubmitDto.class);
		Map<String,Object> map = new HashMap<String,Object>();


			String user_NAME = orderSubmitDto.getUSER_NAME();
			String eff_DATE = orderSubmitDto.getEFF_DATE();
			String exp_DATE = orderSubmitDto.getEXP_DATE();
			String pricing = orderSubmitDto.getPRICING();
			SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmss");
			SimpleDateFormat sdf2 = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
			String SERIAL = sdf.format(new Date());
			map.put("SERIAL", SERIAL);
			map.put("USER_NAME", user_NAME);
			map.put("EFF_DATE", eff_DATE);
			map.put("EXP_DATE", exp_DATE);
			map.put("PRICING", pricing);
			map.put("ORDER_DATE", sdf2.format(new Date()));
			map.put("STATUS", "已结算");
			map.put("ORDER_CONTENT", JSONObject.toJSONString(orderSubmitDto));
			//订单
			orderMapper.addSubmintOrder(map);

			List<OrderSubmitOfferDto> orderSubmitOfferDtoList = orderSubmitDto.getOrderSubmitOfferDtoList();
			for (OrderSubmitOfferDto orderSubmitOfferDto : orderSubmitOfferDtoList) {
				map.put("OFFER_ID", orderSubmitOfferDto.getOFFER_ID());
				List<OfferEntity> queryOffer = orderMapper.queryOffer(map);
				OfferEntity off= new OfferEntity();
				off.setOFFER_ID(orderSubmitOfferDto.getOFFER_ID());
				queryOffer.add(off);

				//offer实例
				for (OfferEntity offerEntity : queryOffer) {
					map.put("OFFER_ID", offerEntity.getOFFER_ID());
					orderMapper.addOfferOrder(map);
					//offer_attr
					List<OfferAttrEntity> queryOfferAttr = orderMapper.queryOfferAttr(map);
					for (OfferAttrEntity offerAttrEntity : queryOfferAttr) {

						Map<String, Object> map1 = new HashMap<>();
						map1.put("USER_NAME",map.get("USER_NAME"));
						map1.put("OFFER_ID",map.get("OFFER_ID"));
						map1.put("SERIAL",map.get("SERIAL"));
						map1.put("EFF_DATE",map.get("EFF_DATE"));
						map1.put("EXP_DATE",map.get("EXP_DATE"));
						map1.put("ATTR_ID", offerAttrEntity.getATTR_ID());
						map1.put("ATTR_VALUE", offerAttrEntity.getDEFAULT_VALUE());
//						map1.put("USER_NAME",1);
//						map1.put("OFFER_ID",2);
//						map1.put("SERIAL",3);
//						map1.put("EFF_DATE",4);
//						map1.put("EXP_DATE",5);
//						map1.put("ATTR_ID", 6);
//						map1.put("ATTR_VALUE", 7);
						orderMapper.addOfferAttr(map1);
					}

					//offer_rel
					List<OfferRelEntity> queryOfferRel = orderMapper.queryOfferRel(map);
					for (OfferRelEntity offerRelEntity : queryOfferRel) {
						OfferInstRelEntity oi = new OfferInstRelEntity();
						oi.setCUST_ID(user_NAME);
						oi.setOFFER_ID(offerRelEntity.getOFFER_ID());
						oi.setPAR_OFFER_ID(offerRelEntity.getPAR_OFFER_ID());
						oi.setSTATUS_CD("已上架");
						oi.setEFF_DATE(eff_DATE);
						oi.setEXP_DATE(exp_DATE);
						orderMapper.addOfferRel(oi);
					}
				}

				//产品
				Map<String,Object> pmap = new HashMap<String,Object>();
				List<OrderSubmitProDto> proDtoList = orderSubmitOfferDto.getProDtoList();
				for (OrderSubmitProDto orderSubmitProDto : proDtoList) {

					String prod_ID = orderSubmitProDto.getPROD_ID();
					pmap.put("PROD_ID", prod_ID);
					pmap.put("USER_NAME", user_NAME);
					pmap.put("SERIAL", SERIAL);
					pmap.put("EFF_DATE", eff_DATE);
					pmap.put("EXP_DATE", exp_DATE);
					List<ProductEntity> queryProd = orderMapper.queryProd(pmap);

					ProductEntity pe= new ProductEntity();
					pe.setPROD_ID(orderSubmitProDto.getPROD_ID());
					queryProd.add(pe);
					for (ProductEntity productEntity : queryProd) {
						pmap.put("PROD_ID", productEntity.getPROD_ID());
//						orderMapper.addProdInstOrder(pmap);
						productEntity.setUSER_NAME(user_NAME);
						productEntity.setSERIAL(SERIAL);
						productEntity.setEFF_DATE(eff_DATE);
						productEntity.setEXP_DATE(exp_DATE);
						orderMapper.addProdInstOrder(productEntity);
						System.out.println("ddddddddddddddddd"+productEntity.getPROD_INST_ID());
						List<ProdAttrEntity> queryProdAttr = orderMapper.queryProdAttr(pmap);
						for (ProdAttrEntity prodAttrEntity : queryProdAttr) {
							pmap.put("PROD_INST_ID",productEntity.getPROD_INST_ID());
							pmap.put("ATTR_ID", prodAttrEntity.getATTR_ID());
							pmap.put("ATTR_VALUE", prodAttrEntity.getDEFAULT_VALUE());
							orderMapper.addProdInstAttrOrder(pmap);
						}
						//prod_rel
						List<ProdRelEntity> queryProdRel = orderMapper.queryProdRel(pmap);
						for (ProdRelEntity prodRelEntity : queryProdRel) {
							ProdInstRelEntity pr = new ProdInstRelEntity();
							pr.setCUST_ID(user_NAME);
							pr.setPROD_ID(prodRelEntity.getPROD_ID());
							pr.setPAR_PROD_ID(prodRelEntity.getPAR_PROD_ID());
							pr.setSTATUS_CD("已上架");
							pr.setEFF_DATE(eff_DATE);
							pr.setEXP_DATE(exp_DATE);
							orderMapper.addProdInstRel(pr);
						}

						//和offer的关系
						pmap.put("REL_TYPE","M");
						List<OfferProdRelEntity> queryOfferProdRel = orderMapper.queryOfferProdRel(pmap);

						for (OfferProdRelEntity offerProdRelEntity : queryOfferProdRel) {
							Map<String, Object> rmap = new HashMap<String, Object>();
							rmap.put("USER_NAME",user_NAME);
							rmap.put("OFFER_ID", offerProdRelEntity.getOFFER_ID());
							rmap.put("PROD_ID", offerProdRelEntity.getPROD_ID());
							orderMapper.addOfferProdInstRel(rmap);
						}


					}


				}

				//加装包
				List<OrderSubmitAddedDto> addedDtoList = orderSubmitOfferDto.getAddedDtoList();
				Map<String,Object> amap = new HashMap<String,Object>();
				for (OrderSubmitAddedDto orderSubmitProDto : addedDtoList) {
					String prod_ID = orderSubmitProDto.getPROD_ID();
					amap.put("PROD_ID", prod_ID);
					amap.put("USER_NAME", user_NAME);
					amap.put("SERIAL", SERIAL);
					amap.put("EFF_DATE", eff_DATE);
					amap.put("EXP_DATE", exp_DATE);
					List<ProductEntity> queryProd = orderMapper.queryProd(amap);

					ProductEntity pe= new ProductEntity();
					pe.setPROD_ID(orderSubmitProDto.getPROD_ID());
					queryProd.add(pe);
					for (ProductEntity productEntity : queryProd) {
						amap.put("PROD_ID", productEntity.getPROD_ID());
//						orderMapper.addProdInstOrder(amap);
						productEntity.setUSER_NAME(user_NAME);
						productEntity.setSERIAL(SERIAL);
						productEntity.setEFF_DATE(eff_DATE);
						productEntity.setEXP_DATE(exp_DATE);
						orderMapper.addProdInstOrder(productEntity);
						List<ProdAttrEntity> queryProdAttr = orderMapper.queryProdAttr(amap);
						for (ProdAttrEntity prodAttrEntity : queryProdAttr) {
							amap.put("PROD_INST_ID", productEntity.getPROD_INST_ID());
							amap.put("ATTR_ID", prodAttrEntity.getATTR_ID());
							amap.put("ATTR_VALUE", prodAttrEntity.getDEFAULT_VALUE());
							orderMapper.addProdInstAttrOrder(amap);
						}
						//prod_rel
						List<ProdRelEntity> queryProdRel = orderMapper.queryProdRel(amap);
						for (ProdRelEntity prodRelEntity : queryProdRel) {
							ProdInstRelEntity pr = new ProdInstRelEntity();
							pr.setCUST_ID(user_NAME);
							pr.setPROD_ID(prodRelEntity.getPROD_ID());
							pr.setPAR_PROD_ID(prodRelEntity.getPAR_PROD_ID());
							pr.setSTATUS_CD("已上架");
							pr.setEFF_DATE(eff_DATE);
							pr.setEXP_DATE(exp_DATE);
							orderMapper.addProdInstRel(pr);
						}
						//和offer的关系
						amap.put("REL_TYPE","A");
						List<OfferProdRelEntity> queryOfferProdRel = orderMapper.queryOfferProdRel(amap);

						for (OfferProdRelEntity offerProdRelEntity : queryOfferProdRel) {
							Map<String, Object> rmap = new HashMap<String, Object>();
							rmap.put("USER_NAME",user_NAME);
							rmap.put("OFFER_ID", offerProdRelEntity.getOFFER_ID());
							rmap.put("PROD_ID", offerProdRelEntity.getPROD_ID());
							orderMapper.addOfferProdInstRel(rmap);
						}

					}


				}



				//产品销售品

				//清除购物车
				orderMapper.clearOfferCart(map);


			}


		return null;
	}

	@Override
	public List<OrderCartDto> addCartOrder2(String order) {
		// TODO Auto-generated method stub
		return null;
	}


}
